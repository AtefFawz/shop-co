"use client";

import { useMemo } from "react";
import Link from "next/link";
import { Sparkles, ArrowUpRight } from "lucide-react";
import { Product } from "@/types";
import Card from "@/features/catalog/components/ProductCard";
import Heading from "@/shared/components/ui/SectionHeading";
import useData from "@/hooks/getData";
import { ProductGridSkeleton } from "@/shared/components/ui/ProductGridSkeleton";
import { useLocale } from "@/shared/i18n/LocaleProvider";

const EMPTY_PRODUCTS: Product[] = [];

export const RelatedProductsSection = ({
  productItem,
}: {
  productItem: Product;
}) => {
  const { t, direction } = useLocale();
  const { data: sectionData, loading: loadingSection } = useData("/product", {
    params: { section: productItem?.section || null },
    limit: 12,
  });
  const { data: categoryData, loading: loadingCategory } = useData("/product", {
    params: { category: productItem?.category || null },
    limit: 12,
  });
  const allProducts = useMemo(() => {
    const sectionProducts: Product[] = sectionData?.data?.Products ?? EMPTY_PRODUCTS;
    const categoryProducts: Product[] = categoryData?.data?.Products ?? EMPTY_PRODUCTS;
    return [...sectionProducts, ...categoryProducts];
  }, [sectionData, categoryData]);

  // Prefer same-section products, then same-category products; avoid arbitrary first-page results.
  const recommendations = useMemo(() => {
    const others = allProducts.filter((item) => item._id !== productItem?._id);
    const sameSection = others.filter(
      (item) => item.section === productItem?.section,
    );
    const sameCategory = others.filter(
      (item) => item.category === productItem?.category,
    );

    const combined = [...sameSection, ...sameCategory, ...others];
    const uniqueMap = new Map<string, Product>();
    combined.forEach((p) => {
      if (p?._id && !uniqueMap.has(p._id)) {
        uniqueMap.set(p._id, p);
      }
    });

    return Array.from(uniqueMap.values()).slice(0, 4);
  }, [allProducts, productItem]);

  if (loadingSection || loadingCategory) {
    return (
      <div className="grid grid-cols-2 gap-1.5 sm:gap-3 gap-y-5 md:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <ProductGridSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (recommendations.length === 0) return null;

  return (
    <div dir={direction} className="space-y-8">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <div className="mb-1.5 inline-flex items-center gap-2 rounded-full border border-border-subtle bg-surface px-3 py-1 shadow-2xs">
            <Sparkles size={11} className="text-primary" />
            <span className="text-xs font-black uppercase tracking-[0.22em] text-secondary">
              {t("relatedCuratedRecommendations")}
            </span>
          </div>
          <Heading
            title={t("relatedYouMightAlsoLike")}
            styling="!text-start !my-0"
          />
        </div>

        <Link
          href="/shop"
          className="group inline-flex w-fit items-center gap-2 rounded-full border border-border-strong bg-surface px-5 py-2.5 text-xs font-black uppercase tracking-widest text-primary shadow-2xs transition-all hover:border-border-strong hover:bg-action hover:text-on-action"
        >
          <span>{t("relatedExploreArchive")}</span>
          <ArrowUpRight
            size={14}
            className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
          />
        </Link>
      </div>

      {/* 4-Column Responsive Grid */}
      <div className="grid grid-cols-2 gap-1.5 sm:gap-3 gap-y-5 md:grid-cols-3 lg:grid-cols-4">
        {recommendations.map((item: Product) => (
          <Card key={item._id} product={item} />
        ))}
      </div>
    </div>
  );
};
