import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/productServer";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/dashboard", "/auth", "/api", "/cart", "/checkout", "/orders"],
    },
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
